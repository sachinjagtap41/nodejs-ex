﻿
namespace SimpleEchoBot
{
    public class Constants
    {
        public static readonly string KeyApi = "APIEndpint";
        public static readonly string DefaultOption = "1";
        public static readonly string PNGType = "image/png";
        public static readonly string Choose = "Choose";
        public static readonly string EmptyLine = "\n";
    }
}