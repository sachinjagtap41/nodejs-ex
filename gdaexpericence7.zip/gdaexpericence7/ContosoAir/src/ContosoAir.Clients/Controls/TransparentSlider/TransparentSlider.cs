﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Controls
{
    public class TransparentSlider : Slider
    {

    }
}