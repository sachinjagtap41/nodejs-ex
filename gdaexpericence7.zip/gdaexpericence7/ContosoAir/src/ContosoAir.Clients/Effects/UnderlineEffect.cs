﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Effects
{
    public class UnderlineEffect : RoutingEffect
    {
        public UnderlineEffect() :  base("ContosoAir.UnderlineEffect")
        {

        }
    }
}