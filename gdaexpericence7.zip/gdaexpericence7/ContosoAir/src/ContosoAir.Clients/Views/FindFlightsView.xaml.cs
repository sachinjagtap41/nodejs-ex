﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class FindFlightsView : ContentPage
    {
        public FindFlightsView()
        {
            InitializeComponent();
        }
    }
}
