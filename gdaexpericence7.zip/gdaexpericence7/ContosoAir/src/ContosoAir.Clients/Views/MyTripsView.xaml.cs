﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class MyTripsView : ContentPage
    {
        public MyTripsView()
        {
            InitializeComponent();
        }
    }
}