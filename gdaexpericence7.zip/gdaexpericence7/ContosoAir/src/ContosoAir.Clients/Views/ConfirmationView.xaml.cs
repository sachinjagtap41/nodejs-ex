﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class ConfirmationView : ContentPage
    {
        public ConfirmationView()
        {
            InitializeComponent();
        }
    }
}
