﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class SignUpView : ContentPage
    {
        public SignUpView()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
