﻿using System;
using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class MainView : MasterDetailPage
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}