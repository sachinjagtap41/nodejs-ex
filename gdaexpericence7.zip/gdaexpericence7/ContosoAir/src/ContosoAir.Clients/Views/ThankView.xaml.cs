﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class ThankView : ContentPage
    {
        public ThankView()
        {
            InitializeComponent();
        }
    }
}