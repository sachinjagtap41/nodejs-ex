﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class MenuItemTemplate : ContentView
    {
        public MenuItemTemplate()
        {
            InitializeComponent();
        }
    }
}
