﻿using Xamarin.Forms;

namespace ContosoAir.Clients.Views
{
    public partial class MenuView : ContentPage
    {
        public MenuView()
        {
            InitializeComponent();
        }
    }
}