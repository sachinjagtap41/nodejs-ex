﻿namespace ContosoAir.Clients.ViewModels.Base
{
    public class MessengerKeys
    {
        // CheckIn done
        public const string CheckInDone = "CheckInDone";

        // CheckIn done
        public const string NotificationRequest = "NotificationRequest";
    }
}