﻿namespace ContosoAir.Clients.Validations
{
    public interface IValidity
    {
        bool IsValid { get; set; }
    }
}
