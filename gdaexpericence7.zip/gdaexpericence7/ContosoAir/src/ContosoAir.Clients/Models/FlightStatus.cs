﻿namespace ContosoAir.Clients.Models
{
    public enum FlightStatus
    {
        None,
        CheckInAvailable,
        AlreadyChecked,
        Delayed
    }
}
