﻿namespace ContosoAir.Clients.Models
{
    class FlightFeedbackData
    {
        public float ratingOnEmotion { get; set; }
        public string feedbackText { get; set; }
        public string flightId { get; set; }
    }
}
