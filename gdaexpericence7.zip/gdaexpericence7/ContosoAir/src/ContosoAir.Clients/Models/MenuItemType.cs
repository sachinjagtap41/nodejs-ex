﻿namespace ContosoAir.Clients.Models
{
    public enum MenuItemType
    {
        MyTrips,
        FindFlights,
        Contact,
        Profile
    }
}