﻿namespace ContosoAir.Clients.Models
{
    public class Notification
    {
        public string Tag { get; set; }
        public NotificationType Type { get; set; }
    }
}
