﻿namespace ContosoAir.Clients.Models
{
    public enum NotificationType
    {
        None,
        CheckInAvailable,
        DelayedFlight,
        GiveFeedback
    }
}
