﻿namespace ContosoAir.Clients.Models
{
    public class Profile
    {
        public string Name { get; set; }
        public string Image { get; set; }
        public string Email { get; set; }
        public string Skype { get; set; }
    }
}