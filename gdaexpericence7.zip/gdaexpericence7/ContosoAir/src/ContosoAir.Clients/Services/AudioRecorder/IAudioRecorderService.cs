﻿namespace ContosoAir.Clients.Services.AudioRecorder
{
    public interface IAudioRecorderService
    {
        void StartRecording();
        void StopRecording();
    }
}
